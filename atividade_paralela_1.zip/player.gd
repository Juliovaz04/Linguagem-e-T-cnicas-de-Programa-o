extends CharacterBody2D

@export var player_name: String = "Player"
@export var color: Color = Color.WHITE
@export var left_action: String = ""
@export var right_action: String = ""
@export var jump_action: String = ""

const SPEED := 260.0
const JUMP_VELOCITY := -470.0
const GRAVITY := 1200.0

func _ready() -> void:
    var shape := CollisionShape2D.new()
    var rect := RectangleShape2D.new()
    rect.size = Vector2(34, 46)
    shape.shape = rect
    add_child(shape)
    queue_redraw()

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y += GRAVITY * delta

    if Input.is_action_just_pressed(jump_action) and is_on_floor():
        velocity.y = JUMP_VELOCITY

    var direction := Input.get_axis(left_action, right_action)
    velocity.x = direction * SPEED

    if direction == 0:
        velocity.x = move_toward(velocity.x, 0, SPEED * 0.15)

    move_and_slide()

    # Impede que os personagens saiam pelas laterais da tela.
    global_position.x = clamp(global_position.x, 20.0, 780.0)

func _draw() -> void:
    # Corpo simples, sem necessidade de imagens externas.
    draw_rect(Rect2(-17, -23, 34, 46), color, true)
    draw_circle(Vector2(0, -30), 12, color.lightened(0.15))
    draw_circle(Vector2(-4, -32), 2.5, Color.BLACK)
    draw_circle(Vector2(4, -32), 2.5, Color.BLACK)
    draw_string(ThemeDB.fallback_font, Vector2(-25, -52), player_name,
        HORIZONTAL_ALIGNMENT_CENTER, 50, 14, Color.WHITE)
