extends StaticBody2D

@export var size := Vector2(120, 20)

func _ready() -> void:
    var shape := CollisionShape2D.new()
    var rect := RectangleShape2D.new()
    rect.size = size
    shape.shape = rect
    add_child(shape)
    queue_redraw()

func _draw() -> void:
    draw_rect(Rect2(-size / 2.0, size), Color(0.93, 0.42, 0.22), true)
    draw_rect(Rect2(-size / 2.0, Vector2(size.x, 5)), Color(1.0, 0.72, 0.45), true)
