extends Area2D

signal player_reached(player_name: String)

var portal_color := Color(0.1, 0.65, 1.0)
var active := true

func _ready() -> void:
    var shape := CollisionShape2D.new()
    var circle := CircleShape2D.new()
    circle.radius = 35
    shape.shape = circle
    add_child(shape)
    body_entered.connect(_on_body_entered)
    queue_redraw()

func _on_body_entered(body: Node2D) -> void:
    if not active:
        return
    if body.has_method("get") and body.get("player_name") != null:
        active = false
        player_reached.emit(str(body.player_name))

func _draw() -> void:
    draw_circle(Vector2.ZERO, 38, Color(0.02, 0.08, 0.18, 0.9))
    draw_arc(Vector2.ZERO, 34, 0, TAU, 64, portal_color, 8.0)
    draw_arc(Vector2.ZERO, 25, 0, TAU, 64, Color(0.25, 0.85, 1.0, 0.75), 5.0)
    draw_circle(Vector2.ZERO, 16, Color(0.02, 0.18, 0.32, 0.9))
