extends Node2D

const Player = preload("res://player.gd")
const Platform = preload("res://platform.gd")
const Portal = preload("res://portal.gd")

var game_over := false
var message_label: Label
var debug_label: Label

func _ready() -> void:
    _create_background()
    _create_title()
    _create_platforms()
    _create_players()
    _create_portal()
    _create_instructions()
    _create_debug_area()

func _create_background() -> void:
    var bg := ColorRect.new()
    bg.position = Vector2.ZERO
    bg.size = Vector2(800, 600)
    bg.color = Color(0.12, 0.14, 0.18)
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(bg)
    move_child(bg, 0)

func _create_title() -> void:
    var title := Label.new()
    title.position = Vector2(20, 12)
    title.size = Vector2(760, 35)
    title.text = "DISPUTA PELO PORTAL"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 24)
    add_child(title)

func _create_platforms() -> void:
    var positions := [
        Vector2(400, 560),
        Vector2(180, 485), Vector2(390, 485), Vector2(620, 485),
        Vector2(280, 420), Vector2(510, 420),
        Vector2(160, 360), Vector2(370, 350), Vector2(620, 355),
        Vector2(270, 285), Vector2(500, 280),
        Vector2(150, 220), Vector2(350, 205), Vector2(590, 210),
        Vector2(250, 145), Vector2(460, 130), Vector2(650, 145)
    ]
    var sizes := [
        Vector2(700, 25),
        Vector2(130, 18), Vector2(130, 18), Vector2(130, 18),
        Vector2(125, 18), Vector2(125, 18),
        Vector2(125, 18), Vector2(125, 18), Vector2(125, 18),
        Vector2(125, 18), Vector2(125, 18),
        Vector2(125, 18), Vector2(125, 18), Vector2(125, 18),
        Vector2(125, 18), Vector2(125, 18), Vector2(125, 18)
    ]

    for i in positions.size():
        var p := Platform.new()
        p.position = positions[i]
        p.size = sizes[i]
        add_child(p)

func _create_players() -> void:
    var p1 := Player.new()
    p1.name = "Player1"
    p1.player_name = "Player 1"
    p1.color = Color(0.95, 0.25, 0.22)
    p1.left_action = "p1_left"
    p1.right_action = "p1_right"
    p1.jump_action = "p1_jump"
    p1.position = Vector2(100, 510)
    add_child(p1)

    var p2 := Player.new()
    p2.name = "Player2"
    p2.player_name = "Player 2"
    p2.color = Color(0.18, 0.55, 1.0)
    p2.left_action = "p2_left"
    p2.right_action = "p2_right"
    p2.jump_action = "p2_jump"
    p2.position = Vector2(700, 510)
    add_child(p2)

func _create_portal() -> void:
    var portal := Portal.new()
    portal.name = "Portal"
    portal.position = Vector2(400, 78)
    portal.player_reached.connect(_on_player_won)
    add_child(portal)

func _create_instructions() -> void:
    var label := Label.new()
    label.position = Vector2(18, 75)
    label.size = Vector2(765, 48)
    label.text = "PLAYER 1: A / D para mover e W para pular     |     PLAYER 2: ← / → para mover e ↑ para pular"
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.add_theme_font_size_override("font_size", 14)
    add_child(label)

    message_label = Label.new()
    message_label.position = Vector2(185, 235)
    message_label.size = Vector2(430, 90)
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    message_label.add_theme_font_size_override("font_size", 24)
    message_label.visible = false
    add_child(message_label)

func _create_debug_area() -> void:
    debug_label = Label.new()
    debug_label.position = Vector2(18, 585)
    debug_label.size = Vector2(764, 20)
    debug_label.text = "Debug: aguardando vencedor..."
    debug_label.add_theme_font_size_override("font_size", 12)
    add_child(debug_label)

func _on_player_won(winner: String) -> void:
    if game_over:
        return

    game_over = true
    print(winner + " ganhou!")
    debug_label.text = "Debug: " + winner + " ganhou! (mensagem enviada com print)"
    message_label.text = winner + " CHEGOU PRIMEIRO!\nParabéns!"
    message_label.visible = true

    # Pausa os jogadores e espera 2 segundos antes de recarregar.
    get_tree().paused = true
    await get_tree().create_timer(2.0, true).timeout
    get_tree().paused = false
    get_tree().reload_current_scene()
