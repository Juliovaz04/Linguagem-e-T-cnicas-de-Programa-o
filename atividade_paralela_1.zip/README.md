# Atividade Paralela 1 – Semana 10

Projeto feito em Godot 4 para a atividade de Fundamentos de Desenvolvimento de Jogos Digitais.

## Como executar
1. Abra o Godot 4.
2. Clique em **Importar**.
3. Selecione a pasta deste projeto.
4. Abra `project.godot`.
5. Aperte **F6/F5** para executar.

## Controles
- Player 1: **A/D** para esquerda/direita e **W** para pular.
- Player 2: **setas esquerda/direita** e **seta para cima** para pular.

## Regras
Os dois jogadores precisam chegar ao portal no topo. O primeiro a tocar no portal vence.
Quando alguém vence:
- o nome do vencedor aparece na tela;
- o comando `print()` registra o vencedor no Output/Debug do Godot;
- o jogo espera 2 segundos;
- a cena é recarregada automaticamente.

## Observação
O projeto usa formas desenhadas pelo próprio Godot, então não depende de sprites externos.
